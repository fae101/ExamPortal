using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ExamPortalApis.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class ExamController : ControllerBase
  {
  }
}
